import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'results-page',
    templateUrl: './results-page.html'
})
export class ResultsPage implements OnInit {

    constructor() {}

    ngOnInit() {}
}