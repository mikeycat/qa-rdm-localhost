export * from './modal/operating-systems-modal';
export * from './page/operating-systems-page';
export * from './table/operating-systems-table';