import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'sessions-page',
    templateUrl: './sessions-page.html'
})
export class SessionsPage implements OnInit {

    constructor() {}

    ngOnInit() {}
}