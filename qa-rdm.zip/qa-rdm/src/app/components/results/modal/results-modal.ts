import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'results-modal',
    templateUrl: './results-modal.html'
})
export class ResultsModal implements OnInit {

    constructor() {}

    ngOnInit() {}
}