import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'sessions-modal',
    templateUrl: './sessions-modal.html'
})
export class SessionsModal implements OnInit {

    constructor() {}

    ngOnInit() {}
}