export * from './modal/platforms-modal';
export * from './page/platforms-page';
export * from './table/platforms-table';