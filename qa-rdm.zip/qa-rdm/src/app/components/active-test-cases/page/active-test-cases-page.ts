import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'active-tests-page',
    templateUrl: './active-test-cases-page.html'
})
export class ActiveTestsPage implements OnInit {

    table_update: boolean = true;

    constructor() {}

    ngOnInit() {}
}