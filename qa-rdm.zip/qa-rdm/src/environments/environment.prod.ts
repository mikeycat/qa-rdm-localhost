export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDteKpHwXB_Qgj5jpqScDA32HgXKThNXDI",
    authDomain: "endtest-reporting.firebaseapp.com",
    databaseURL: "https://endtest-reporting.firebaseio.com",
    projectId: "endtest-reporting",
    storageBucket: "endtest-reporting.appspot.com",
    messagingSenderId: "128097668197"
  }
};
