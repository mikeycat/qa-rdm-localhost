import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'users-table',
    templateUrl: './users-table.html'
})
export class UsersTable implements OnInit {

    constructor() {}

    ngOnInit() {}
}